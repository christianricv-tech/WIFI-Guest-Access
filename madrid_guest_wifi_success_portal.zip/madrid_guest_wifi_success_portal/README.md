# S.P. Madrid Guest Wi-Fi — Success Page

This is a success/connected page styled using the visual theme of the supplied second screenshot: SPM logo above the card, pale blue abstract background, blue gradient card header, and floating animation.

The content keeps the first screenshot's connection-success setup, with the session message changed to **1 hour**.

## Deploy
1. Back up your existing `index.html` first.
2. Upload this `index.html` to the root of your `WIFI-Guest` GitHub repository.
3. Commit the change and confirm GitHub Pages is publishing from the correct branch/folder.

## Important
This page is a display-only success page. It does not authenticate voucher codes or enforce a one-hour network session. Configure the Aruba captive portal/backend to enforce the actual session timeout. Use the login/voucher page as the portal entry page and set this page as the post-authentication redirect.
